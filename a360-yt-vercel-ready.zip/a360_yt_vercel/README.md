# YT Downloader API (Vercel-ready)

This is a **minimal extraction** of the `plugins/yt.py` functionality from your `A360API-main.zip`, refactored to run as a **Vercel Python Serverless Function**.

## Endpoints

- `GET /` → health + endpoint list
- `GET /yt/search?query=KEYWORDS` → YouTube search results
- `GET /yt/dl?url=YOUTUBE_URL` → attempts to resolve a downloadable URL via a third‑party provider

> ⚠️ Please use responsibly and only download content you have rights/permission to download.

## Deploy to Vercel

1. Create a GitHub repo and push this code.
2. In Vercel: **New Project → Import Git Repo → Deploy**

## Local run (optional)

Vercel functions run serverless, but you can test logic locally with any ASGI server:

```bash
pip install -r requirements.txt
uvicorn api.index:app --reload
```

Then open:
- http://127.0.0.1:8000/
- http://127.0.0.1:8000/yt/search?query=music


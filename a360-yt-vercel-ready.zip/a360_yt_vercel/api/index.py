import re
import html
import logging
from collections import OrderedDict

import requests
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from py_yt import VideosSearch, Search
from mangum import Mangum

# Basic logger (works on Vercel)
logger = logging.getLogger("a360-yt")
logger.setLevel(logging.INFO)

app = FastAPI(
    title="YT Downloader API (A360 extract)",
    description=(
        "Serverless FastAPI for Vercel. "
        "Use responsibly and only download content you have rights/permission to."  # policy-friendly note
    ),
    version="1.0.0",
)


def extract_video_id(url: str):
    patterns = [
        r"(?:https?:\/\/)?(?:www\.)?youtube\.com\/watch\?v=([^&?\s]+)",
        r"(?:https?:\/\/)?youtu\.be\/([^&?\s]+)",
        r"(?:https?:\/\/)?(?:www\.)?youtube\.com\/embed\/([^&?\s]+)",
        r"(?:https?:\/\/)?(?:www\.)?youtube\.com\/v\/([^&?\s]+)",
        r"(?:https?:\/\/)?(?:www\.)?youtube\.com\/shorts\/([^&?\s]+)",
    ]
    for pattern in patterns:
        m = re.match(pattern, url)
        if m:
            return m.group(1)
    q = re.search(r"v=([^&?\s]+)", url)
    if q:
        return q.group(1)
    return None


def parse_duration(duration_str: str):
    try:
        if not duration_str:
            return "N/A"
        parts = duration_str.split(":")
        hours = minutes = seconds = 0
        if len(parts) == 3:
            hours, minutes, seconds = map(int, parts)
        elif len(parts) == 2:
            minutes, seconds = map(int, parts)
        elif len(parts) == 1:
            seconds = int(parts[0])

        formatted = ""
        if hours > 0:
            formatted += f"{hours}h "
        if minutes > 0:
            formatted += f"{minutes}m "
        if seconds > 0:
            formatted += f"{seconds}s"
        return formatted.strip() or "0s"
    except Exception:
        return "N/A"


async def fetch_youtube_details(video_id: str):
    try:
        src = VideosSearch(video_id, limit=1)
        data = await src.next()
        if not data or not data.get("result"):
            return {"error": "No video found for the provided ID."}
        video = data["result"][0]
        return {
            "title": html.unescape(video.get("title", "N/A")),
            "channel": html.unescape(video.get("channel", {}).get("name", "N/A")),
            "description": html.unescape(video.get("description", "N/A")),
            "tags": video.get("tags", []),
            "imageUrl": video.get("thumbnails", [{}])[-1].get("url", ""),
            "duration": parse_duration(video.get("duration", "")),
            "views": video.get("viewCount", {}).get("short", "N/A"),
            "likes": video.get("accessibility", {}).get("likes", "N/A") if video.get("accessibility") else "N/A",
            "comments": "N/A",
        }
    except Exception as e:
        logger.exception("fetch_youtube_details error: %s", e)
        return {"error": "Failed to fetch YouTube video details."}


async def fetch_youtube_search(query: str):
    try:
        src = Search(query, limit=10)
        data = await src.next()
        if not data or not data.get("result"):
            return {"error": "No videos found for the provided query."}

        result = []
        for item in data["result"]:
            if item.get("type") != "video":
                continue
            result.append(
                {
                    "title": html.unescape(item.get("title", "N/A")),
                    "channel": html.unescape(item.get("channel", {}).get("name", "N/A")),
                    "tags": [],
                    "imageUrl": item.get("thumbnails", [{}])[-1].get("url", ""),
                    "link": item.get("link", ""),
                    "duration": parse_duration(item.get("duration", "")),
                    "views": item.get("viewCount", {}).get("short", "N/A"),
                    "likes": item.get("accessibility", {}).get("likes", "N/A") if item.get("accessibility") else "N/A",
                    "comments": "N/A",
                }
            )
        return result or {"error": "No videos found for the provided query."}
    except Exception as e:
        logger.exception("fetch_youtube_search error: %s", e)
        return {"error": "Failed to fetch search data."}


@app.get("/")
async def root():
    return {
        "ok": True,
        "endpoints": {
            "download": "/yt/dl?url=YOUTUBE_URL",
            "search": "/yt/search?query=KEYWORDS",
        },
        "note": "Use responsibly and only for content you have rights/permission to download.",
    }


@app.get("/yt/dl")
async def download(url: str = ""):
    if not url:
        return JSONResponse(
            status_code=400,
            content={"error": "Missing 'url' parameter."},
        )

    video_id = extract_video_id(url)
    if not video_id:
        return JSONResponse(status_code=400, content={"error": "Invalid YouTube URL."})

    standard_url = f"https://www.youtube.com/watch?v={video_id}"
    youtube_data = await fetch_youtube_details(video_id)

    if "error" in youtube_data:
        youtube_data = {
            "title": "Unavailable",
            "channel": "N/A",
            "description": "N/A",
            "tags": [],
            "imageUrl": f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg",
            "duration": "N/A",
            "views": "N/A",
            "likes": "N/A",
            "comments": "N/A",
        }

    # Original project used Clipto API to resolve downloadable URLs.
    # NOTE: External providers can change/break; Vercel serverless also has execution time limits.
    try:
        resp = requests.post("https://www.clipto.com/api/youtube", json={"url": standard_url}, timeout=20)

        ordered = OrderedDict()
        ordered["title"] = html.unescape(youtube_data.get("title", "N/A"))
        ordered["channel"] = youtube_data.get("channel", "N/A")
        ordered["description"] = youtube_data.get("description", "N/A")
        ordered["tags"] = youtube_data.get("tags", [])
        ordered["thumbnail_url"] = f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg"
        ordered["url"] = standard_url
        ordered["duration"] = youtube_data.get("duration", "N/A")
        ordered["views"] = youtube_data.get("views", "N/A")
        ordered["likes"] = youtube_data.get("likes", "N/A")
        ordered["comments"] = youtube_data.get("comments", "N/A")

        if resp.status_code == 200:
            data = resp.json()
            # Keep Clipto response but ensure our ordered keys are present
            ordered["title"] = html.unescape(data.get("title", ordered["title"]))
            ordered["thumbnail"] = data.get("thumbnail", youtube_data.get("imageUrl", ""))
            ordered["resolved_url"] = data.get("url", standard_url)
            for k, v in data.items():
                if k not in ordered:
                    ordered[k] = v
            return JSONResponse(content=dict(ordered))

        ordered["error"] = "Failed to fetch download URL from provider."
        return JSONResponse(content=dict(ordered), status_code=502)

    except requests.RequestException as e:
        logger.exception("provider request error: %s", e)
        return JSONResponse(status_code=502, content={"error": "Provider request failed."})


@app.get("/yt/search")
async def search(query: str = ""):
    if not query:
        return JSONResponse(status_code=400, content={"error": "Missing 'query' parameter."})

    search_data = await fetch_youtube_search(query)
    if isinstance(search_data, dict) and "error" in search_data:
        return JSONResponse(status_code=502, content={"error": search_data["error"]})

    return {"result": search_data}


# Vercel entrypoint
handler = Mangum(app)
